// Dedicated gateway invoice page. Payment state is always read from FINZZ's
// authenticated API; the browser never marks an invoice paid or credits balance.
import { el, Button, Card, Alert, Skeleton, PageHeader, toast } from '../ui.js';
import { icon } from '../icons.js';
import { appShell } from './_app-shell.js';
import { ApiError } from '../api.js';
import { formatRupiah, formatDate } from '../store.js';

export default async function invoicePage(ctx) {
  const { api, layout, navigate } = ctx;
  const id = new URLSearchParams(window.location.search).get('id');
  const area = el('div', { class: 'stack' }, new Skeleton({ card: true }));
  const content = el('div', { class: 'page animate-rise' },
    PageHeader({ eyebrow: 'Pembayaran', iconName: 'receipt', tone: 'mint', title: 'Invoice deposit', subtitle: 'Selesaikan pembayaran sebelum waktu invoice berakhir. Saldo masuk setelah status pembayaran diverifikasi server.' }),
    area,
    el('div', { class: 'row row--wrap' },
      Button({ variant: 'outline', iconName: 'arrowLeft', children: 'Kembali ke dompet', onClick: () => navigate('/wallet') }),
      Button({ variant: 'ghost', iconName: 'refresh', children: 'Periksa status', onClick: () => load() })
    )
  );
  const { shell } = appShell(layout, 'wallet', content);
  let disposed = false;
  let timer = null;
  let pollBusy = false;

  const load = async () => {
    if (!id) {
      area.replaceChildren(Alert({ tone: 'danger', title: 'Invoice tidak ditemukan', children: 'Buka invoice dari proses top-up di halaman dompet.' }));
      return;
    }
    try {
      const result = await api.get(`/api/deposits/${encodeURIComponent(id)}`, { retries: 0, timeout: 10000 });
      if (disposed) return;
      const d = result.deposit;
      if (!d || d.method !== 'gateway') {
        area.replaceChildren(Alert({ tone: 'danger', title: 'Invoice tidak valid', children: 'Invoice ini bukan pembayaran otomatis.' }));
        return;
      }
      const paid = d.status === 'completed' || d.status === 'approved';
      const expired = d.status === 'cancelled' || d.status === 'expired';
      const expires = d.payment?.expiresAt ? Date.parse(d.payment.expiresAt) : NaN;
      const seconds = Number.isFinite(expires) ? Math.max(0, Math.floor((expires - Date.now()) / 1000)) : null;
      const timerText = seconds === null ? 'Waktu kedaluwarsa belum tersedia' : seconds <= 0 ? 'Invoice kedaluwarsa' : `Sisa waktu ${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
      area.replaceChildren(Card({ title: `Invoice ${d.payment?.reference || d.id}`, subtitle: formatDate(d.createdAt), children: [
        paid ? Alert({ tone: 'success', title: 'Pembayaran terverifikasi', children: 'Saldo telah diproses oleh server. Kamu bisa kembali ke dashboard.' })
          : expired ? Alert({ tone: 'warning', title: 'Invoice kedaluwarsa', children: 'Buat invoice baru dari halaman dompet jika pembayaran belum dilakukan.' })
            : Alert({ tone: 'info', title: 'Menunggu pembayaran', children: 'Pindai QRIS melalui aplikasi pembayaran. Jangan unggah bukti transfer untuk invoice otomatis.' }),
        d.payment?.qrisImage && !paid && !expired ? el('div', { class: 'qris-payment__panel stack', style: { alignItems: 'center' } },
          el('img', { class: 'qris-payment__image', attrs: { src: d.payment.qrisImage, alt: 'QRIS invoice FINZZ Store', width: '280', height: '280', loading: 'eager', decoding: 'async' } }),
          el('span', { class: 'text-xs text-dim', text: timerText })
        ) : null,
        el('div', { class: 'row row--between row--wrap' }, el('span', { text: 'Saldo yang diterima' }), el('strong', { class: 'mono', text: formatRupiah(d.amount) })),
        el('div', { class: 'row row--between row--wrap' }, el('span', { text: 'Total pembayaran' }), el('strong', { class: 'mono', text: formatRupiah(d.payment?.payAmount ?? d.amount) })),
        d.payment?.feeAmount > 0 ? el('div', { class: 'row row--between row--wrap' }, el('span', { class: 'text-sm text-dim', text: 'Biaya gateway' }), el('span', { class: 'mono', text: formatRupiah(d.payment.feeAmount) })) : null,
        d.payment?.checkoutUrl && !paid && !expired ? el('a', { class: 'btn btn--outline btn--block', attrs: { href: d.payment.checkoutUrl, target: '_blank', rel: 'noopener noreferrer' }, text: 'Buka halaman pembayaran alternatif' }) : null,
        el('p', { class: 'text-xs text-dim', text: 'Status diperiksa otomatis setiap 5 detik. Jangan melakukan pembayaran berulang untuk invoice yang sama.' })
      ] }));
    } catch (err) {
      if (disposed) return;
      area.replaceChildren(Alert({ tone: 'danger', title: 'Gagal memuat invoice', children: err instanceof ApiError ? err.message : 'Periksa koneksi lalu coba lagi.' }));
    }
  };

  await load();
  timer = setInterval(async () => {
    if (disposed || pollBusy) return;
    pollBusy = true;
    try { await load(); } finally { pollBusy = false; }
  }, 5000);
  return { node: shell, title: 'Invoice Deposit — FINZZ Store', cleanup: () => { disposed = true; if (timer) clearInterval(timer); } };
}
