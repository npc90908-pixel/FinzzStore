# Integration privacy contract

FINZZ Store does not disclose the identities of its upstream catalogue or automatic-payment integrations to customers.

- Public health/configuration responses expose only generic availability flags.
- Public catalogue and quote responses use generic source labels such as `live`, `cached`, `demo`, and `unavailable`.
- Wallet/deposit DTOs do not include the payment provider name or provider-hosted checkout URL. QRIS is rendered in the FINZZ interface.
- Browser bundles and customer-facing error messages use generic integration wording.
- Operational logs use generic event names and normalized error codes; raw upstream bodies, credentials, and stack traces are not exposed as customer messages.
- `.env.example` and public documentation use generic variable names. Legacy environment variable aliases remain supported in server configuration to avoid breaking existing deployments.
- Actual upstream credentials, endpoint routing, webhook verification, and supplier/payment identifiers must remain server-side. Never place these values in public settings, frontend code, or customer API responses.

The generic webhook paths are `/api/webhooks/supplier` and `/api/webhooks/payment`. Configure callback destinations only in the relevant private integration dashboards. Keep the integration signature headers expected by the upstream services unchanged; they are verified on the server.
