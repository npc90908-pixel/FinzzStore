-- Vercel's /tmp filesystem is ephemeral and per-instance. Store manual deposit
-- proof bytes in PostgreSQL so admin review works across serverless instances.
begin;

alter table public.deposits add column if not exists proof_data bytea;

create or replace function public.rpc_create_deposit(
  p_user_id uuid,
  p_amount numeric,
  p_proof_path text,
  p_proof_mime text,
  p_proof_size integer,
  p_proof_sha256 text,
  p_proof_data bytea,
  p_user_note text,
  p_min_amount numeric,
  p_max_amount numeric,
  p_max_pending integer
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_deposit public.deposits;
  v_pending integer;
  v_min_amount numeric := greatest(coalesce(p_min_amount, 1000), 1000);
begin
  if p_amount is null or p_amount <= 0 then
    raise exception using errcode = 'P0001', message = 'INVALID_AMOUNT';
  end if;
  if p_amount < v_min_amount then
    raise exception using errcode = 'P0001', message = 'DEPOSIT_BELOW_MINIMUM';
  end if;
  if p_amount > p_max_amount then
    raise exception using errcode = 'P0001', message = 'DEPOSIT_ABOVE_MAXIMUM';
  end if;
  if p_proof_mime is null or p_proof_size is null or p_proof_data is null then
    raise exception using errcode = 'P0001', message = 'PROOF_REQUIRED';
  end if;
  if p_proof_mime not in ('image/png','image/jpeg','image/webp','application/pdf') then
    raise exception using errcode = 'P0001', message = 'PROOF_INVALID_TYPE';
  end if;
  if p_proof_size <= 0 or p_proof_size > 5242880 or octet_length(p_proof_data) <> p_proof_size then
    raise exception using errcode = 'P0001', message = 'PROOF_TOO_LARGE';
  end if;

  select count(*) into v_pending from public.deposits
   where user_id = p_user_id and status = 'pending';
  if v_pending >= coalesce(p_max_pending, 3) then
    raise exception using errcode = 'P0001', message = 'TOO_MANY_PENDING_DEPOSITS';
  end if;

  insert into public.deposits
    (user_id, amount, method, status, proof_path, proof_mime, proof_size, proof_sha256, proof_data, user_note)
  values
    (p_user_id, p_amount, 'manual_transfer', 'pending', coalesce(p_proof_path, 'database'), p_proof_mime,
     p_proof_size, p_proof_sha256, p_proof_data, left(coalesce(p_user_note, ''), 500))
  returning * into v_deposit;

  -- Never return the binary payload in the RPC JSON response.
  return jsonb_build_object('deposit', to_jsonb(v_deposit) - 'proof_data');
end;
$$;

revoke all on function public.rpc_create_deposit(uuid,numeric,text,text,integer,text,bytea,text,numeric,numeric,integer) from public, anon, authenticated;
grant execute on function public.rpc_create_deposit(uuid,numeric,text,text,integer,text,bytea,text,numeric,numeric,integer) to service_role;

commit;
